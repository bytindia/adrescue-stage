(function () {
    "use strict";

    let initializedForms = new Set();
    let submissionInProgress = new Set();

    /* Load CSS */
    function loadCSS() {
        if (document.getElementById("rockstar-widget-css")) return;

        const link = document.createElement("link");
        link.id = "rockstar-widget-css";
        link.rel = "stylesheet";
        link.href =
            "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/css/intlTelInput.css";
        document.head.appendChild(link);
    }

    /* Load intl-tel-input JS */
    function loadIntl(callback) {
        if (window.intlTelInput) {
            callback();
            return;
        }

        if (document.getElementById("rockstar-intl-js")) {
            const intv = setInterval(() => {
                if (window.intlTelInput) {
                    clearInterval(intv);
                    callback();
                }
            }, 50);
            return;
        }

        const script = document.createElement("script");
        script.id = "rockstar-intl-js";
        script.src =
            "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/intlTelInput.min.js";
        script.onload = callback;
        document.head.appendChild(script);
    }

    /* Inject Widget Styles */
    function injectStyles() {
        if (document.getElementById("rockstar-widget-styles")) return;

        const style = document.createElement("style");
        style.id = "rockstar-widget-styles";
        style.textContent = `

/* Allow clicks inside TagMango popup */
.tm-popup *, 
.tm-modal *, 
#_mango_overlay *, 
.mango-overlay *,
.tm-overlay * {
    pointer-events: auto !important;
}

.enquiry-widget, .close-icon1 {
    pointer-events: auto !important;
    z-index: 999999 !important;
}

/* Container */
.enquiry-widget {
    position: relative;
    font-family: "Segoe UI", Arial, sans-serif;
    width: 450px;
    max-width: 95%;
    background: rgba(255,255,255,0.97);
    border-radius: 22px;
    padding: 35px 28px;
    box-shadow: 0 18px 50px rgba(0,0,0,0.25);
    animation: popup 0.28s ease-out;
    backdrop-filter: blur(12px);
    border: 1px solid rgba(220,220,220,0.45);
}

/* Title */
.enquiry-widget h3 {
    text-align: center;
    margin-bottom: 24px;
    font-size: 24px;
    font-weight: 700;
    color: #1a2a44;
}

/* Inputs */
.enquiry-widget input {
    width: 100%;
    padding: 14px 16px;
    margin-bottom: 12px;
    border-radius: 14px;
    border: 1px solid #ccc;
    background: #fafafa;
    transition: 0.2s ease;
}

.iti {
    width: 100% !important;
}
.iti input {
    padding-left: 90px !important;
}

/* Submit Button */
.enquiry-widget button {
    width: 100%;
    margin-top: 8px;
    background: linear-gradient(135deg, #0066ff, #004bcc);
    color: #fff;
    border: none;
    padding: 15px;
    border-radius: 14px;
    font-size: 17px;
    cursor: pointer;
    transition: 0.25s;
    font-weight: 600;
}
.enquiry-widget button:hover:not(:disabled) {
    background: linear-gradient(135deg, #004bcc, #003699);
    box-shadow: 0 8px 25px rgba(0,70,200,0.35);
    transform: translateY(-2px);
}

/* Close Icon */
.close-icon1 {
    position: absolute;
    top: 14px;
    right: 14px;
    width: 35px;
    height: 35px;
    font-size: 26px;
    background: rgba(255,255,255,0.95);
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    font-weight: bold;
    transition: 0.25s;
}
.close-icon1:hover {
    transform: scale(1.18);
    background: #fff;
    color: #000;
}

/* Response */
.eq-error { color: #d62828; font-size: 13px; margin-bottom: 8px; }
.eq-response { margin-top: 12px; font-size: 14px; text-align:center; color: #2a9d8f; }

/* Animation */
@keyframes popup {
    from { transform: scale(0.85); opacity:0; }
    to { transform: scale(1); opacity:1; }
}

@media(max-width:768px){
    .enquiry-widget { padding: 28px 22px; }
    .enquiry-widget h3 { font-size: 20px; }
    .enquiry-widget input { padding: 12px; }
}

`;
        document.head.appendChild(style);
    }

    function getParam(key) {
        return new URLSearchParams(window.location.search).get(key) || "";
    }

    /* Initialize a Form */
    function initForm(id) {
        const container = document.getElementById(id);
        if (!container || initializedForms.has(id)) return;

        container.innerHTML = `
            <div class="enquiry-widget">
                <span class="close-icon1" data-close="${id}">&times;</span>
                <h3>Sign Up Now</h3>

                <input type="text" id="${id}-name" placeholder="Your Name" />
                <div id="${id}-err-name" class="eq-error"></div>

                <input type="email" id="${id}-email" placeholder="Your Email" />
                <div id="${id}-err-email" class="eq-error"></div>

                <input type="tel" id="${id}-phone" placeholder="Phone Number" />
                <div id="${id}-err-phone" class="eq-error"></div>

                <button id="${id}-submit">Submit</button>
                <div id="${id}-response" class="eq-response"></div>
            </div>
        `;

        loadIntl(() => {
            const phone = document.getElementById(id + "-phone");
            phone._itiInstance = window.intlTelInput(phone, {
                initialCountry: "in",
                preferredCountries: ["in", "us", "ae"],
                separateDialCode: true,
                nationalMode: false,
            });
        });

        /* CLOSE BUTTON FIX FOR TAGMANGO POPUPS */
        const closeBtn = container.querySelector(`[data-close="${id}"]`);

        closeBtn.addEventListener("click", function (e) {
    e.preventDefault();
    e.stopPropagation();

    // 1️⃣ Close TagMango modal (your exact popup wrapper)
    const tmPopup = container.closest(".modal, [name='custom-popUp-mainMod']");
    if (tmPopup) tmPopup.style.display = "none";

    // 2️⃣ Close TM overlay (TagMango always uses this ID)
    const overlay = document.getElementById("_mango_overlay");
    if (overlay) overlay.style.display = "none";

    // 3️⃣ Trigger internal TagMango close event (for safety)
    window.postMessage({ type: "TM_CLOSE_POPUP" }, "*");

    // IMPORTANT: Do NOT hide your form container
    // container.style.display = 'none';  <-- REMOVE THIS
});


        /* Submit Handler */
        const submitBtn = document.getElementById(id + "-submit");
        submitBtn.addEventListener("click", function (e) {
            e.preventDefault();
            handleSubmit(id);
        });

        initializedForms.add(id);
    }

    /* Submit Logic */
    function handleSubmit(id) {
        if (submissionInProgress.has(id)) return;

        const name = document.getElementById(id + "-name").value.trim();
        const email = document.getElementById(id + "-email").value.trim();
        const phoneEl = document.getElementById(id + "-phone");

        const errName = document.getElementById(id + "-err-name");
        const errEmail = document.getElementById(id + "-err-email");
        const errPhone = document.getElementById(id + "-err-phone");
        const response = document.getElementById(id + "-response");

        errName.innerText = "";
        errEmail.innerText = "";
        errPhone.innerText = "";
        response.innerText = "";

        let valid = true;

        if (!/^[A-Za-z\s]{2,}$/.test(name)) {
            errName.innerText = "Enter a valid name.";
            valid = false;
        }

        if (!/^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(email)) {
            errEmail.innerText = "Enter a valid email.";
            valid = false;
        }

        const digits = phoneEl.value.replace(/\D/g, "");
        if (digits.length !== 10) {
            errPhone.innerText = "Phone must be 10 digits.";
            valid = false;
        }

        if (!valid) return;

        const iti = phoneEl._itiInstance;
        const code = "+" + iti.getSelectedCountryData().dialCode;
        const fullPhone = code + digits;

        const submitBtn = document.getElementById(id + "-submit");
        submitBtn.disabled = true;
        submitBtn.innerText = "Submitting...";

        submissionInProgress.add(id);

        let fd = new FormData();
        fd.append("name", name);
        fd.append("email", email);
        fd.append("phone", fullPhone);
        fd.append("form_id", id);
        fd.append("source", getParam("utm_source"));
        fd.append("medium", getParam("utm_medium"));
        fd.append("campaign", getParam("utm_campaign"));
        fd.append("gclid", getParam("gclid"));
        fd.append("fbclid", getParam("fbclid"));
        fd.append("ad_id", getParam("ad_id"));
        fd.append("landing_page", window.location.href);
        fd.append('page_url', window.location.origin + window.location.pathname);

        fetch("https://adsninja.adrescue.in/webhook/rockstar-leads-save.php", {
            method: "POST",
            body: fd,
        })
            .then((r) => r.json())
            .then((r) => {
                submissionInProgress.delete(id);
                if (r.status === "success") {
                    response.innerText = "Thank you! Redirecting...";
                    setTimeout(() => {
                        window.location.href =
                            "https://school.rockstarshub.com/services/thankyou";
                    }, 1200);
                } else {
                    response.innerText = r.message || "Error. Try again.";
                    submitBtn.disabled = false;
                    submitBtn.innerText = "Submit";
                }
            })
            .catch(() => {
                submissionInProgress.delete(id);
                response.innerText = "Server error!";
                submitBtn.disabled = false;
                submitBtn.innerText = "Submit";
            });
    }

    function initAll() {
        document
            .querySelectorAll(".widget-form")
            .forEach((div) => initForm(div.id));
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => {
            loadCSS();
            injectStyles();
            initAll();
        });
    } else {
        loadCSS();
        injectStyles();
        initAll();
    }

    window.RockstarWidget = {
        init: initForm,
        initAll: initAll,
    };
})();
